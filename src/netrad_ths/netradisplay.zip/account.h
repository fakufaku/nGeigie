#ifndef ACCOUNT_H
#define ACCOUNT_H

// Your API key (Get yours at https://api.safecast.org/#profile-modal after registration)
const char *apiKey = "z5H2f3pvUGf1zp81Gcmq";

//IPAddress serverIP (50, 112, 106, 155);		// api.safecast.org
IPAddress serverIP (176, 56, 236, 75);		//  Lionel's timestamp logger workaround

IPAddress localIP (192, 168, 1, 40);			// falback localIP address

#endif ACCOUNT_H
// vim: set tabstop=4 shiftwidth=4 syntax=c foldmethod=marker :
